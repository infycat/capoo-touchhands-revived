# Capoo v1.0.4 架構與資料分析

本文件說明本版如何從原始 ActionScript 3 與 SWF 輸入，建成 Android 及 Windows 套件，以及玩法流程中哪些資料會影響得分、時間和排行榜。

## 系統結構

~~~mermaid
flowchart TB
  subgraph Inputs[原始輸入]
    AS3[capoo_source/as3_original/capoo_fla]
    SWF[capoo_source/swf/capoo.swf]
    ICON[assets/icons]
  end
  subgraph Build[重建流程]
    IMPORT[swf-toolkit import-as3]
    MOB[build/android/as3 + application.xml]
    DESK[build/desktop/as3 + application.xml]
    MBUILD[capoo-mobile.swf]
    DBUILD[capoo-desktop.swf]
    PACK[build-release.ps1 + AIR ADT]
  end
  subgraph Outputs[發布輸出]
    APK[Universal APK]
    WIN[Windows x64 ZIP]
    SRC[Source ZIP]
  end
  AS3 --> IMPORT
  SWF --> IMPORT
  IMPORT --> MOB --> MBUILD --> PACK --> APK
  IMPORT --> DESK --> DBUILD --> PACK --> WIN
  ICON --> MOB
  ICON --> DESK
  AS3 --> SRC
  SWF --> SRC
  MOB --> SRC
  DESK --> SRC
~~~

## 啟動與遊戲流程

~~~mermaid
flowchart TD
  A[啟動應用] --> B[原版 SWF 時間軸]
  B --> C[SQLite 開啟或建立 gamed 表]
  C --> D[主選單]
  D -->|開始| E[跳轉至遊戲流程]
  D -->|排行榜| R[讀取本機前五名]
  E --> F[隨機顯示左右拍手位置]
  F --> G{玩家輸入}
  G -->|正確六區之一| H[命中數 +1]
  H --> I[連擊階段與 score 更新]
  I --> J[追加 1–2 個 100 ms 計時刻度]
  J --> F
  G -->|錯誤區域| K[錯誤動畫與當前命中狀態處理]
  K --> F
  F --> L{計時結束}
  L -->|否| G
  L -->|是| M[結算、經驗值與排名比較]
  M --> N[如進入前五名則儲存玩家名稱/分數]
  N --> O[排行榜更新並返回主選單]
  R --> D
~~~

正確輸入的分支由原版六個 TouchEvent handler 實作。桌面副本的 <code>onHandMouse</code> 依被點擊的 MovieClip 呼叫同一組六個 handler，因此兩個平台共用玩法判斷、動畫和計分邏輯。移植層沒有另寫一套遊戲規則。

## 原始程式碼對照

| 路徑 | 內容 | 用途 |
| --- | --- | --- |
| <code>capoo_source/as3_original/capoo_fla/</code> | 17 個原始 AS3 類別 | 保存反編譯取得的時間軸腳本與原始遊戲邏輯 |
| <code>capoo_source/swf/capoo.swf</code> | 原始 SWF，7,318,593 bytes | 提供時間軸、美術、動畫、聲音及符號 |
| <code>build/android/as3/</code> | 18 個 AS3 類別 | 手機版 TouchEvent 和原始遊戲資料流程 |
| <code>build/desktop/as3/</code> | 18 個 AS3 類別 | 同一玩法邏輯，加上滑鼠輸入轉接 |
| <code>build/rebuild-swfs.ps1</code> | SWF 重建腳本 | 把平台 AS3 副本重新匯入原始 SWF |
| <code>build/build-release.ps1</code> | 正式封裝流程 | 建置 Windows bundle、Android APK、檢查 manifest/簽章並產出 SHA-256 |

平台副本保留時間軸和場景；建置時以空實作 AdMobManager 解決原 SWF 中殘留的廣告類別參照，沒有封裝舊 ANE，也沒有加入廣告請求。

## 玩法數據

以下數字從 v1.0.4 發佈用 AS3 程式碼讀取。它們是程式設計常數和排名格式，不是玩家遙測。

| 變數或結構 | 解讀 |
| --- | --- |
| <code>L1/L2/L3/R1/R2/R3</code> | 六個可點／可觸控的位置 |
| <code>total_time = 100</code>、<code>Timer(100)</code> | 初始 100 個 100 ms 刻度；每次正確命中按階段補回 2 或 1 格 |
| <code>hit_sum</code> | 正確命中計數；結算畫面顯示此數，排名以此比較 |
| <code>combos = 51/203/302</code> | 低於 20、20 起、50 起三階段的內部 score 增量 |
| 100、200 命中 | 背景動畫進度門檻 |
| <code>gamed</code> SQLite table | 一列保存五組 name/score 欄位及狀態欄位，供前五名排行榜讀寫 |

score 與 hit_sum 分開使用：score 累積連擊階段加分並參與經驗值計算；排行榜排序依 hit_sum。這避免把畫面上的命中數和內部升級分數混為一談。

## 平台與打包分析

- **Android**：application ID <code>air.air.capoo</code>、versionCode <code>1000004</code>；最低 API 23、target API 36。
- **ABI**：<code>arm64-v8a</code>、<code>armeabi-v7a</code>、<code>x86</code>、<code>x86_64</code> 四種均存在於 APK。
- **權限**：aapt dump permissions 只有 package 列，沒有 uses-permission。
- **Runtime**：Android 使用 captive runtime；Windows ZIP 包含 Adobe AIR 執行環境、CapooOriginal.exe 和 icons。
- **簽章**：新長期證書 SHA-256 為 <code>806e00840b245c1f6a430e6ae2aae1d064cde8b078bc2ff224f8f5173a8ba1d8</code>。因與官方舊簽章不同，需先卸載舊 APK；卸載會清除舊版本機資料，後續更新必須沿用新私鑰。
- **發佈物大小**：APK 41,828,516 bytes；Windows ZIP 16,025,680 bytes。

## 驗證範圍

使用者已確認測試版遊戲功能驗收通過。正式版重新設定 release label 後再封裝；build-release.ps1 驗證 package/versionCode、target API、icon、零權限和 APK 證書指紋。詳細版本雜湊與環境見 <code>TEST-REPORT.md</code>。

## 復現與版本保存

舊 v1.0.3 的 boot shim、舊 README、Git tag 及 APK Release 保持獨立且未被新版本取代。v1.0.4 完整源碼包不含簽章金鑰、DPAPI 密碼、測試輸出或編譯中間檔。重建正式簽署版本時，先為自己建立本機私鑰，再執行 build-release.ps1；不同簽章會造成 Android 覆蓋安裝拒絕。
