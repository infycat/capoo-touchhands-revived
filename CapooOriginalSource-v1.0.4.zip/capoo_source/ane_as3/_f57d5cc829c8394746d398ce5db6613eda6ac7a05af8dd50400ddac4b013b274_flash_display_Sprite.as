// swf-toolkit: abc=7 class=0
package
{
   import flash.display.Sprite;
   import flash.system.Security;

   public class _f57d5cc829c8394746d398ce5db6613eda6ac7a05af8dd50400ddac4b013b274_flash_display_Sprite extends Sprite
   {

      public function _f57d5cc829c8394746d398ce5db6613eda6ac7a05af8dd50400ddac4b013b274_flash_display_Sprite()
      {
      }

      [__go_to_definition_help(pos="602")]
      public function allowDomainInRSL(...rest):void
      {
         Security.allowDomain.apply(null, rest);
      }

      [__go_to_definition_help(pos="922")]
      public function allowInsecureDomainInRSL(...rest):void
      {
         Security.allowInsecureDomain.apply(null, rest);
      }
   }
}
