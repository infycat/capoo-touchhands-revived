// swf-toolkit: abc=4 class=0
package com.admob
{
   import flash.events.EventDispatcher;
   import flash.events.StatusEvent;
   import flash.external.ExtensionContext;
   import flash.system.Capabilities;
   import flash.utils.Dictionary;

   public class AdMobManager extends EventDispatcher
   {

      [__go_to_definition_help(pos="575")]
      private static const LOG_TAG:String = "AdMobAne_AS3";
      [__go_to_definition_help(pos="671")]
      public static const TEST_MODE:Boolean = false;
      [__go_to_definition_help(pos="722")]
      public static const PROD_MODE:Boolean = true;
      [__go_to_definition_help(pos="799")]
      public static const GENDER_UNDEFINED:int = 0;
      [__go_to_definition_help(pos="848")]
      public static const GENDER_MALE:int = 1;
      [__go_to_definition_help(pos="894")]
      public static const GENDER_FEMALE:int = 2;
      [__go_to_definition_help(pos="977")]
      public static const IOS:String = "iOS";
      [__go_to_definition_help(pos="1023")]
      public static const ANDROID:String = "Android";
      [__go_to_definition_help(pos="1470")]
      private static var mManager:AdMobManager = null;

      [__go_to_definition_help(pos="1087")]
      private const ANE_NAME:String = "com.admob.ane";
      [__go_to_definition_help(pos="1179")]
      private const ID_IOS:String = "iOS";
      [__go_to_definition_help(pos="1223")]
      private const ID_ANDROID:String = "Android";
      [__go_to_definition_help(pos="1309")]
      private const ID_TEST_MODE:String = "Testing Mode";
      [__go_to_definition_help(pos="1366")]
      private const ID_PROD_MODE:String = "Production Mode";
      [__go_to_definition_help(pos="1544")]
      private var mCtx:ExtensionContext = null;
      [__go_to_definition_help(pos="1591")]
      private var mDispatcher:EventDispatcher = null;
      [__go_to_definition_help(pos="1643")]
      private var mBannersAdMobId:String = null;
      [__go_to_definition_help(pos="1691")]
      private var mInterstitialAdMobId:String = null;
      [__go_to_definition_help(pos="1743")]
      private var mTestDeviceID:String = null;
      [__go_to_definition_help(pos="1789")]
      private var mOperationMode:Boolean = false;
      [__go_to_definition_help(pos="1838")]
      private var mVerbose:Boolean = false;
      [__go_to_definition_help(pos="1882")]
      private var mDevice:String = null;
      [__go_to_definition_help(pos="1924")]
      private var mBannersDic:Dictionary = null;
      [__go_to_definition_help(pos="1972")]
      private var mIsInterstitialCreated:Boolean = false;
      [__go_to_definition_help(pos="2027")]
      private var mInterstitialAutoShow:Boolean = false;
      [__go_to_definition_help(pos="2111")]
      private var mGender:int = 0;
      [__go_to_definition_help(pos="2148")]
      private var mBirthYear:int = 0;
      [__go_to_definition_help(pos="2187")]
      private var mBirthMonth:int = 0;
      [__go_to_definition_help(pos="2227")]
      private var mBirthDay:int = 0;
      [__go_to_definition_help(pos="2265")]
      private var mIsCDT:Boolean = false;

      {
         LOG_TAG = "AdMobAne_AS3";
         TEST_MODE = false;
         PROD_MODE = true;
         GENDER_UNDEFINED = 0;
         GENDER_MALE = 1;
         GENDER_FEMALE = 2;
         IOS = "iOS";
         ANDROID = "Android";
         mManager = null;
      }

      public function AdMobManager()
      {
         super();
         this.mCtx = ExtensionContext.createExtensionContext(this.ANE_NAME, null);
         if(this.ctx)
         {
            this.ctx.addEventListener(StatusEvent.STATUS, this.onStatus);
         }
      }

      [__go_to_definition_help(pos="2601")]
      public static function get manager():AdMobManager
      {
         if(!mManager)
         {
            mManager = new this();
         }
         return mManager;
      }

      [__go_to_definition_help(pos="2854")]
      public function get dispatcher():EventDispatcher
      {
         if(!this.mDispatcher)
         {
            this.mDispatcher = new EventDispatcher();
         }
         return this.mDispatcher;
      }

      [__go_to_definition_help(pos="3137")]
      private function get ctx():ExtensionContext
      {
         return this.mCtx;
      }

      [__go_to_definition_help(pos="3242")]
      public function get bannersAdMobId():String
      {
         return this.mBannersAdMobId;
      }

      [__go_to_definition_help(pos="3318")]
      public function set bannersAdMobId(id:String):void
      {
         this.mBannersAdMobId = id;
      }

      [__go_to_definition_help(pos="3447")]
      public function get interstitialAdMobId():String
      {
         return this.mInterstitialAdMobId;
      }

      [__go_to_definition_help(pos="3533")]
      public function set interstitialAdMobId(id:String):void
      {
         this.mInterstitialAdMobId = id;
      }

      [__go_to_definition_help(pos="3670")]
      public function get operationMode():Boolean
      {
         return this.mOperationMode;
      }

      [__go_to_definition_help(pos="3745")]
      public function set operationMode(mode:Boolean):void
      {
         if(!this.isSupported)
         {
            this.log(LOG_TAG, "Cannot set the operatioon Mode, the extension is not supported or not initialized");
            return;
         }
         this.mOperationMode = mode;
         this.log(LOG_TAG, "Native SetMode Call Performed!");
         this.ctx.call(AdMobFunctions.SET_MODE, this.mOperationMode);
         return;
      }

      [__go_to_definition_help(pos="4240")]
      public function get verbose():Boolean
      {
         return this.mVerbose;
      }

      [__go_to_definition_help(pos="4303")]
      public function set verbose(mode:Boolean):void
      {
         if(!this.isSupported)
         {
            this.log(LOG_TAG, "Cannot set the verbose Mode, the extension is not supported or not initialized.");
            return;
         }
         this.mVerbose = mode;
         this.log(LOG_TAG, "Native SetVerbose Call Performed!");
         this.ctx.call(AdMobFunctions.SET_VERBOSE, this.mVerbose);
         return;
      }

      [__go_to_definition_help(pos="4785")]
      public function get isSupported():Boolean
      {
         if(this.device)
         {
            return true;
         }
         return false;
      }

      [__go_to_definition_help(pos="5047")]
      private function get isInterstitialCreated():Boolean
      {
         return this.mIsInterstitialCreated;
      }

      [__go_to_definition_help(pos="5201")]
      private function get interstitialAutoShow():Boolean
      {
         return this.mInterstitialAutoShow;
      }

      [__go_to_definition_help(pos="5323")]
      public function get device():String
      {
         if(!this.mDevice)
         {
            if(Capabilities.manufacturer.indexOf(this.ID_IOS) > -1)
            {
               this.mDevice = this.ID_IOS;
            }
            if(Capabilities.manufacturer.indexOf(this.ID_ANDROID) > -1)
            {
               this.mDevice = this.ID_ANDROID;
            }
         }
         return this.mDevice;
      }

      [__go_to_definition_help(pos="5745")]
      private function get bannersDic():Dictionary
      {
         if(!this.mBannersDic)
         {
            this.mBannersDic = new Dictionary();
         }
         return this.mBannersDic;
      }

      [__go_to_definition_help(pos="6016")]
      public function get bannersQuantity():int
      {
         var key:String = null;
         var n:int = 0;
         for(key in this.bannersDic)
         {
            n++;
         }
         return n;
      }

      [__go_to_definition_help(pos="6303")]
      public function get bannersNames():Array
      {
         var key:String = null;
         var names:Array = new Array();
         if(this.bannersQuantity > 0)
         {
            for(key in this.bannersDic)
            {
               names.push(key);
            }
         }
         return names;
      }

      [__go_to_definition_help(pos="6680")]
      public function get testDeviceID():String
      {
         return this.mTestDeviceID;
      }

      [__go_to_definition_help(pos="6752")]
      public function set testDeviceID(deviceID:String):void
      {
         if(!this.isSupported)
         {
            this.log(LOG_TAG, "Cannot set the Test Device ID, the extension is not supported or not initialized");
            return;
         }
         if(deviceID == null)
         {
            this.log(LOG_TAG, "Cannot set the Test Device ID, an incorrect value as been passet. Please use the public constant values available in AdMobManager");
            return;
         }
         if(deviceID == "")
         {
            this.log(LOG_TAG, "Cannot set the Test Device ID, an incorrect value as been passet. Please use the public constant values available in AdMobManager");
            return;
         }
         this.mTestDeviceID = deviceID;
         this.log(LOG_TAG, "Native setTestDeviceID Call Performed!");
         this.ctx.call(AdMobFunctions.SET_TEST_DEVICE_ID, this.mTestDeviceID);
         return;
      }

      [__go_to_definition_help(pos="7718")]
      public function get gender():int
      {
         return this.mGender;
      }

      [__go_to_definition_help(pos="7775")]
      public function set gender(sex:int):void
      {
         if(!this.isSupported)
         {
            this.log(LOG_TAG, "Cannot set the Gender, the extension is not supported or not initialized");
            return;
         }
         if(sex < 0 ? sex < 0 : sex > 3)
         {
            this.log(LOG_TAG, "Cannot set the Gender, an incorrect value as been passet. Please use the public constant values available in AdMobManager");
            return;
         }
         this.mGender = sex;
         this.log(LOG_TAG, "Native SetGender Call Performed!");
         this.ctx.call(AdMobFunctions.SET_GENDER, this.mGender);
         return;
      }

      [__go_to_definition_help(pos="8472")]
      public function get birthYear():int
      {
         return this.mBirthYear;
      }

      [__go_to_definition_help(pos="8535")]
      public function set birthYear(year:int):void
      {
         if(!this.isSupported)
         {
            this.log(LOG_TAG, "Cannot set the Birth Year, the extension is not supported or not initialized");
            return;
         }
         var minValue:int = 1910;
         var maxValue:int = 2012;
         if(year < minValue ? year < minValue : year > maxValue)
         {
            this.log(LOG_TAG, "Cannot set the Birth Year, an incorrect value as been passet. The allow value are only Form: " + minValue + " To: " + maxValue);
            return;
         }
         this.mBirthYear = year;
         this.log(LOG_TAG, "Native SetBirthYear Call Performed!");
         this.ctx.call(AdMobFunctions.SET_BIRTHYEAR, this.mBirthYear);
         return;
      }

      [__go_to_definition_help(pos="9472")]
      public function get birthMonth():int
      {
         return this.mBirthMonth;
      }

      [__go_to_definition_help(pos="9537")]
      public function set birthMonth(month:int):void
      {
         if(!this.isSupported)
         {
            this.log(LOG_TAG, "Cannot set the Birth Month, the extension is not supported or not initialized");
            return;
         }
         if(month < 1 ? month < 1 : month > 12)
         {
            this.log(LOG_TAG, "Cannot set the Birth Month, an incorrect value as been passet. The allow value are only Form: 1 To: 12");
            return;
         }
         this.mBirthMonth = month;
         this.log(LOG_TAG, "Native SetBirthMonth Call Performed!");
         this.ctx.call(AdMobFunctions.SET_BIRTHMONTH, this.mBirthMonth);
         return;
      }

      [__go_to_definition_help(pos="10257")]
      public function get birthDay():int
      {
         return this.mBirthDay;
      }

      [__go_to_definition_help(pos="10318")]
      public function set birthDay(day:int):void
      {
         if(!this.isSupported)
         {
            this.log(LOG_TAG, "Cannot set the Birth Day, the extension is not supported or not initialized");
            return;
         }
         if(day < 1 ? day < 1 : day > 31)
         {
            this.log(LOG_TAG, "Cannot set the Birth Day, an incorrect value as been passet. The allow value are only Form: 1 To: 31");
            return;
         }
         this.mBirthDay = day;
         this.log(LOG_TAG, "Native SetBirthDay Call Performed!");
         this.ctx.call(AdMobFunctions.SET_BIRTHDAY, this.mBirthDay);
         return;
      }

      [__go_to_definition_help(pos="11033")]
      public function get isCDT():Boolean
      {
         return this.mIsCDT;
      }

      [__go_to_definition_help(pos="11092")]
      public function set isCDT(val:Boolean):void
      {
         if(!this.isSupported)
         {
            this.log(LOG_TAG, "Cannot set the tag For Child Directed Treatment, the extension is not supported or not initialized");
            return;
         }
         this.mIsCDT = val;
         this.log(LOG_TAG, "Native SetGender Call Performed!");
         this.ctx.call(AdMobFunctions.SET_CDT, this.mIsCDT);
         return;
      }

      [__go_to_definition_help(pos="12240")]
      public function dispose():void
      {
         if(this.ctx != null)
         {
            this.ctx.removeEventListener(StatusEvent.STATUS, this.onStatus);
            this.ctx.dispose();
            this.mCtx = null;
         }
         mManager = null;
      }

      [__go_to_definition_help(pos="13639")]
      public function createBanner(adSize:int, adPosition:int, bannerId:String = null, adMobId:String = null, autoShow:Boolean = false):void
      {
         if(!this.isSupported)
         {
            this.log(LOG_TAG, "Cannot create the banner, the extension is not supported");
            return;
         }
         if(adMobId == null)
         {
            adMobId = this.bannersAdMobId;
         }
         if(adMobId == null)
         {
            this.log(LOG_TAG, "Cannot create the banner, the AdMobId is not set. Please pass an Id during banner creation or set the common Id");
            return;
         }
         if(!bannerId)
         {
            bannerId = this.getBannerId();
         }
         else if(this.bannersDic.hasOwnProperty(bannerId))
         {
            this.log(LOG_TAG, "Cannot create the banner, the a banner with the same id already exist");
            return;
         }
         this.validateTestMode();
         var positionType:int = AdMobBanner.POS_RELATIVE;
         var position:Array = new Array(adPosition);
         var banner:AdMobBanner = new AdMobBanner(adSize, positionType, position, bannerId, adMobId, autoShow);
         this.bannersDic[bannerId] = banner;
         this.log(LOG_TAG, "Native CreateBanner Call Performed!");
         this.ctx.call(AdMobFunctions.BANNER_CREATE, bannerId, adMobId, adSize, positionType, adPosition);
         return;
      }

      [__go_to_definition_help(pos="15993")]
      public function createBannerAbsolute(adSize:int, posX:Number, posY:Number, bannerId:String = null, adMobId:String = null, autoShow:Boolean = false):void
      {
         if(!this.isSupported)
         {
            this.log(LOG_TAG, "Cannot create the banner, the extension is not supported");
            return;
         }
         if(!adMobId)
         {
            adMobId = this.bannersAdMobId;
         }
         if(!adMobId)
         {
            this.log(LOG_TAG, "Cannot create the banner, the AdMobId is not set. Please pass an Id during banner creation or set the common Id");
            return;
         }
         if(!bannerId)
         {
            bannerId = this.getBannerId();
         }
         else if(this.bannersDic.hasOwnProperty(bannerId))
         {
            this.log(LOG_TAG, "Cannot create the banner, the a banner with the same id already exist");
            return;
         }
         this.validateTestMode();
         var positionType:int = AdMobBanner.POS_ABSOLUTE;
         var position:Array = new Array(posX, posY);
         var banner:AdMobBanner = new AdMobBanner(adSize, positionType, position, bannerId, adMobId, autoShow);
         this.bannersDic[bannerId] = banner;
         this.log(LOG_TAG, "Native CreateBanner Call Performed!");
         this.ctx.call(AdMobFunctions.BANNER_CREATE_ABSOLUTE, bannerId, adMobId, adSize, positionType, posX, posY);
         return;
      }

      [__go_to_definition_help(pos="17856")]
      public function showBanner(bannerId:String):void
      {
         if(!this.isSupported)
         {
            this.log(LOG_TAG, "Cannot show the banner, the extension is not supported");
            return;
         }
         if(bannerId == null)
         {
            this.log(LOG_TAG, "Cannot show the banner, the given banner id is invalid");
            return;
         }
         if(!this.bannersDic.hasOwnProperty(bannerId))
         {
            this.log(LOG_TAG, "Cannot show the banner, there is no banner created for the given id");
            return;
         }
         this.log(LOG_TAG, "Native ShowBanner Call Performed!");
         this.ctx.call(AdMobFunctions.BANNER_SHOW, bannerId);
         return;
      }

      [__go_to_definition_help(pos="18867")]
      public function hideBanner(bannerId:String):void
      {
         if(!this.isSupported)
         {
            this.log(LOG_TAG, "Cannot hide the banner, the extension is not supported");
            return;
         }
         if(bannerId == null)
         {
            this.log(LOG_TAG, "Cannot hide the banner, the given banner id is invalid");
            return;
         }
         if(!this.bannersDic.hasOwnProperty(bannerId))
         {
            this.log(LOG_TAG, "Cannot hide the banner, there is no banner created for the given id");
            return;
         }
         this.log(LOG_TAG, "Native HideBanner Call Performed!");
         this.ctx.call(AdMobFunctions.BANNER_HIDE, bannerId);
         return;
      }

      [__go_to_definition_help(pos="20080")]
      public function removeBanner(bannerId:String):void
      {
         if(!this.isSupported)
         {
            this.log(LOG_TAG, "Cannot remove the banner, the extension is not supported");
            return;
         }
         if(bannerId == null)
         {
            this.log(LOG_TAG, "Cannot remove the banner, the given banner id is invalid");
            return;
         }
         if(!this.bannersDic.hasOwnProperty(bannerId))
         {
            this.log(LOG_TAG, "Cannot remove the banner, there is no banner created for the given id");
            return;
         }
         this.bannersDic[bannerId] = null;
         if(this.bannersDic.hasOwnProperty(bannerId))
         {
            delete this.bannersDic[bannerId];
         }
         this.log(LOG_TAG, "Native RemoveBanner Call Performed!");
         this.ctx.call(AdMobFunctions.BANNER_REMOVE, bannerId);
         return;
      }

      [__go_to_definition_help(pos="20967")]
      public function showAllBanner():void
      {
         var banner:AdMobBanner = null;
         if(!this.isSupported)
         {
            this.log(LOG_TAG, "Cannot show the banners, the extension is not supported");
            return;
         }
         for each(banner in this.bannersDic)
         {
            this.showBanner(banner.bannerId);
         }
         return;
      }

      [__go_to_definition_help(pos="21376")]
      public function hideAllBanner():void
      {
         var banner:AdMobBanner = null;
         if(!this.isSupported)
         {
            this.log(LOG_TAG, "Cannot hide the banners, the extension is not supported");
            return;
         }
         for each(banner in this.bannersDic)
         {
            this.hideBanner(banner.bannerId);
         }
         return;
      }

      [__go_to_definition_help(pos="21821")]
      public function removeAllBanner():void
      {
         var banner:AdMobBanner = null;
         if(!this.isSupported)
         {
            this.log(LOG_TAG, "Cannot remove the banners, the extension is not supported");
            return;
         }
         for each(banner in this.bannersDic)
         {
            this.removeBanner(banner.bannerId);
         }
         return;
      }

      [__go_to_definition_help(pos="22849")]
      public function createInterstitial(adMobId:String = null, autoShow:Boolean = false):void
      {
         if(!this.isSupported)
         {
            this.log(LOG_TAG, "Cannot create the Interstitial, the extension is not supported");
            return;
         }
         if(this.isInterstitialCreated)
         {
            this.log(LOG_TAG, "Cannot create the Interstitial, An Interstitial has already been created");
            return;
         }
         if(!adMobId)
         {
            adMobId = this.interstitialAdMobId;
         }
         if(!adMobId)
         {
            this.log(LOG_TAG, "Cannot create the Interstitial, the AdMobId is not set. Please pass an Id during Interstitial creation or set the common Id");
            return;
         }
         this.validateTestMode();
         this.mIsInterstitialCreated = true;
         this.mInterstitialAutoShow = autoShow;
         this.log(LOG_TAG, "Native CreateInterstitial Call Performed!");
         this.ctx.call(AdMobFunctions.INTERSTITIAL_CREATE, adMobId);
         return;
      }

      [__go_to_definition_help(pos="23976")]
      public function removeInterstitial():void
      {
         if(!this.isSupported)
         {
            this.log(LOG_TAG, "Cannot remove the banner, the extension is not supported");
            return;
         }
         if(!this.isInterstitialCreated)
         {
            this.log(LOG_TAG, "Cannot destroy the Interstitial, The Interstitial has not been created yet");
            return;
         }
         this.log(LOG_TAG, "Native removeInterstitial Call Performed!");
         this.ctx.call(AdMobFunctions.INTERSTITIAL_REMOVE);
         this.mIsInterstitialCreated = false;
         this.mInterstitialAutoShow = false;
         return;
      }

      [__go_to_definition_help(pos="25083")]
      public function cacheInterstitial(adMobId:String = null):void
      {
         if(!this.isSupported)
         {
            this.log(LOG_TAG, "Cannot cache the Interstitial, the extension is not supported");
            return;
         }
         if(!adMobId)
         {
            adMobId = this.interstitialAdMobId;
         }
         if(!adMobId)
         {
            this.log(LOG_TAG, "Cannot cache the Interstitial, the AdMobId is not set. Please pass an Id during Interstitial creation or set the common Id");
            return;
         }
         if(!this.isInterstitialCreated)
         {
            this.log(LOG_TAG, "The Interstitial was not available, an Interstitial will be created");
            this.createInterstitial(adMobId);
         }
         this.log(LOG_TAG, "Native CacheInterstitial Call Performed!");
         this.ctx.call(AdMobFunctions.INTERSTITIAL_CACHE, adMobId);
         return;
      }

      [__go_to_definition_help(pos="26252")]
      public function isInterstitialLoaded():Boolean
      {
         if(!this.isSupported)
         {
            this.log(LOG_TAG, "The Interstitial is not ready, and will not be ready, since the extension is not supported");
            return false;
         }
         if(!this.isInterstitialCreated)
         {
            this.log(LOG_TAG, "The Interstitial is not ready, and will not be ready, since the Interstitial was never created");
            return false;
         }
         this.log(LOG_TAG, "Native isInterstitialLoaded Call Performed!");
         var result:Boolean = this.ctx.call(AdMobFunctions.INTERSTITIAL_IS_LOADED);
         return result;
      }

      [__go_to_definition_help(pos="27153")]
      public function showInterstitial():void
      {
         if(!this.isSupported)
         {
            this.log(LOG_TAG, "Cannot show the Interstitial, the extension is not supported!");
            return;
         }
         if(!this.isInterstitialCreated)
         {
            this.log(LOG_TAG, "Cannot show the Interstitial, the Interstitial has not yet been created!");
            return;
         }
         if(!this.isInterstitialLoaded())
         {
            this.log(LOG_TAG, "Cannot show the Interstitial, the Interstitial is not yet ready!");
            return;
         }
         this.log(LOG_TAG, "Native ShowInterstitial Call Performed!");
         this.ctx.call(AdMobFunctions.INTERSTITIAL_SHOW);
         return;
      }

      [__go_to_definition_help(pos="28334")]
      private function onStatus(event:StatusEvent):void
      {
         var bannerId:String = null;
         var banner:AdMobBanner = null;
         trace("ane event ", event.code, event.level);
         var e:AdMobEvent = null;
         var _loc5_ = event.code;
         switch(AdMobEvent.BANNER_LOADED !== _loc5_ ? AdMobEvent.BANNER_FAILED_TO_LOAD !== _loc5_ ? AdMobEvent.BANNER_AD_OPENED !== _loc5_ ? AdMobEvent.BANNER_AD_CLOSED !== _loc5_ ? AdMobEvent.BANNER_LEFT_APPLICATION !== _loc5_ ? AdMobEvent.INTERSTITIAL_LOADED !== _loc5_ ? AdMobEvent.INTERSTITIAL_FAILED_TO_LOAD !== _loc5_ ? AdMobEvent.INTERSTITIAL_AD_OPENED !== _loc5_ ? AdMobEvent.INTERSTITIAL_AD_CLOSED !== _loc5_ ? AdMobEvent.INTERSTITIAL_LEFT_APPLICATION !== _loc5_ ? true ? 10 : 10 : 9 : 8 : 7 : 6 : 5 : 4 : 3 : 2 : 1 : 0)
         {
            case 0:
               this.log(LOG_TAG, "Event Recieved: Banner Loaded!");
               bannerId = event.level;
               banner = this.bannersDic[bannerId];
               if(banner.autoShow)
               {
                  this.showBanner(bannerId);
               }
               e = new AdMobEvent(AdMobEvent.BANNER_LOADED, event.level);
               break;
            case 1:
               this.log(LOG_TAG, "Event Recieved: Banner Failed to Load!");
               e = new AdMobEvent(AdMobEvent.BANNER_FAILED_TO_LOAD, event.level);
               break;
            case 2:
               this.log(LOG_TAG, "Event Recieved: Banner Ad Opened!");
               e = new AdMobEvent(AdMobEvent.BANNER_AD_OPENED, event.level);
               break;
            case 3:
               this.log(LOG_TAG, "Event Recieved: Banner Ad Closed!");
               e = new AdMobEvent(AdMobEvent.BANNER_AD_CLOSED, event.level);
               break;
            case 4:
               this.log(LOG_TAG, "Event Recieved: Banner Has left the Application!");
               e = new AdMobEvent(AdMobEvent.BANNER_LEFT_APPLICATION, event.level);
               break;
            case 5:
               this.log(LOG_TAG, "Event Recieved: Interstitial Loaded!");
               e = new AdMobEvent(AdMobEvent.INTERSTITIAL_LOADED, event.level);
               if(this.mInterstitialAutoShow)
               {
                  this.showInterstitial();
               }
               break;
            case 6:
               this.log(LOG_TAG, "Event Recieved: Interstitial Failed to Load!");
               e = new AdMobEvent(AdMobEvent.INTERSTITIAL_FAILED_TO_LOAD, event.level);
               break;
            case 7:
               this.log(LOG_TAG, "Event Recieved: Interstitial Ad Opened!");
               e = new AdMobEvent(AdMobEvent.INTERSTITIAL_AD_OPENED, event.level);
               break;
            case 8:
               this.log(LOG_TAG, "Event Recieved: Interstitial Ad Closed!");
               e = new AdMobEvent(AdMobEvent.INTERSTITIAL_AD_CLOSED, event.level);
               break;
            case 9:
               this.log(LOG_TAG, "Event Recieved: Interstitial Has left the Application!");
               e = new AdMobEvent(AdMobEvent.INTERSTITIAL_LEFT_APPLICATION, event.level);
               break;
            case 10:
            default:
               break;
         }
         if(e != null)
         {
            this.dispatcher.dispatchEvent(e);
         }
      }

      [__go_to_definition_help(pos="31154")]
      private function validateTestMode():void
      {
         if(this.mOperationMode)
         {
            return;
         }
         if(this.mTestDeviceID == null)
         {
            this.log(LOG_TAG, "IMPORTANT ALLER: You are using the Test mode, however a test device id was not given!");
            this.log(LOG_TAG, "Please set the proprierty '.testDeviceID' correctly, in the current state google will register the impression done by the device");
            this.log(LOG_TAG, "and you may risk to have your account banned!");
            return;
         }
         if(this.mTestDeviceID == "")
         {
            this.log(LOG_TAG, "IMPORTANT ALLER: You are using the Test mode, however a test device id is blank!");
            this.log(LOG_TAG, "Please set the proprierty '.testDeviceID' correctly, in the current state google will register the impression done by the device");
            this.log(LOG_TAG, "and you may risk to have your account banned!");
            return;
         }
         this.log(LOG_TAG, "Test Mode correctly running on device: " + this.mTestDeviceID);
         return;
      }

      [__go_to_definition_help(pos="32388")]
      public function getBannerId():String
      {
         var id:String = this.generateBannerId();
         if(this.bannersQuantity > 0)
         {
            while(this.bannersDic.hasOwnProperty(id))
            {
               id = this.generateBannerId();
            }
         }
         return id;
      }

      [__go_to_definition_help(pos="32900")]
      public function generateBannerId():String
      {
         var id:String = "BannerID";
         var num:int = this.randomRange(0, 1000000);
         id += num;
         return id;
      }

      [__go_to_definition_help(pos="33324")]
      private function randomRange(minNum:int, maxNum:int):int
      {
         return Math.floor(Math.random() * (maxNum - minNum + 1)) + minNum;
      }

      [__go_to_definition_help(pos="33477")]
      final public function moveBanner(bannerId:String, _arg2:Number, _arg3:Number):void
      {
         if(!this.isSupported)
         {
            this.log(LOG_TAG, "Cannot show the banner, the extension is not supported");
            return;
         }
         if(bannerId == null)
         {
            this.log(LOG_TAG, "Cannot show the banner, the given banner id is invalid");
            return;
         }
         if(!this.bannersDic.hasOwnProperty(bannerId))
         {
            this.log(LOG_TAG, "Cannot show the banner, there is no banner created for the given id");
            return;
         }
         this.log(LOG_TAG, "Native ShowBanner Call Performed!");
         this.ctx.call(AdMobFunctions.BANNER_MOVE, bannerId, _arg2, _arg3);
         return;
      }

      [__go_to_definition_help(pos="34161")]
      final public function rotateBanner(bannerId:String, _arg2:Number):void
      {
         if(!this.isSupported)
         {
            this.log(LOG_TAG, "Cannot show the banner, the extension is not supported");
            return;
         }
         if(bannerId == null)
         {
            this.log(LOG_TAG, "Cannot show the banner, the given banner id is invalid");
            return;
         }
         if(!this.bannersDic.hasOwnProperty(bannerId))
         {
            this.log(LOG_TAG, "Cannot show the banner, there is no banner created for the given id");
            return;
         }
         this.log(LOG_TAG, "Native ShowBanner Call Performed!");
         this.ctx.call(AdMobFunctions.BANNER_ROTATE, bannerId, _arg2);
         return;
      }

      [__go_to_definition_help(pos="34828")]
      final public function getScreenSize():ScreenSize
      {
         if(!this.isSupported)
         {
            this.log(LOG_TAG, "Cannot show the banner, the extension is not supported");
            return null;
         }
         var _local1:ScreenSize = this.ctx.call(AdMobFunctions.GET_SCREEN_SIZE) as ScreenSize;
         return _local1;
      }

      [__go_to_definition_help(pos="35117")]
      final public function getBannerSize(_arg1:int):AdSize
      {
         if(_arg1 == AdMobSize.WIDE_SKYSCRAPER)
         {
            this.log("AdMobAne_AS3", "The wide Skyscrapper banner is not supported by Admob, therefore it cannot be measured before creation. Please create the banner and then use the method getExistingBannerSize. Please note that this kind of banner can only be created on specific mediation network.");
            return null;
         }
         if((_arg1 == AdMobSize.SMART_BANNER ? _arg1 == AdMobSize.SMART_BANNER : _arg1 == AdMobSize.SMART_BANNER_LAND) ? _arg1 == AdMobSize.SMART_BANNER ? _arg1 == AdMobSize.SMART_BANNER : _arg1 == AdMobSize.SMART_BANNER_LAND : _arg1 == AdMobSize.SMART_BANNER_PORT)
         {
            this.log("AdMobAne_AS3", "Smart Banner cannot be measured before creation. Please create the banner and then use the method getExistingBannerSize");
            return null;
         }
         return AdMobSize.typeSize(_arg1);
      }

      [__go_to_definition_help(pos="35860")]
      final public function getExistingBannerSize(bannerId:String):AdSize
      {
         if(!this.isSupported)
         {
            this.log(LOG_TAG, "Cannot show the banner, the extension is not supported");
            return null;
         }
         if(bannerId == null)
         {
            this.log(LOG_TAG, "Cannot show the banner, the given banner id is invalid");
            return null;
         }
         if(!this.bannersDic.hasOwnProperty(bannerId))
         {
            this.log(LOG_TAG, "Cannot show the banner, there is no banner created for the given id");
            return null;
         }
         var _local2:AdSize = this.ctx.call(AdMobFunctions.GET_AD_SIZE, bannerId) as AdSize;
         return _local2;
      }

      [__go_to_definition_help(pos="36865")]
      private function log(msg:String, ...rest):void
      {
         var now:Number = (new Date()).time;
         if(this.verbose)
         {
            trace("[" + LOG_TAG + "]", msg, rest);
         }
      }
   }
}
