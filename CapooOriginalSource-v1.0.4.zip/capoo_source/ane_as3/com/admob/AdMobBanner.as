// swf-toolkit: abc=0 class=0
package com.admob
{
   public class AdMobBanner
   {

      [__go_to_definition_help(pos="357")]
      public static const POS_RELATIVE:int = 0;
      [__go_to_definition_help(pos="408")]
      public static const POS_ABSOLUTE:int = 1;

      [__go_to_definition_help(pos="479")]
      private var mBannerId:String;
      [__go_to_definition_help(pos="517")]
      private var mAdSize:int;
      [__go_to_definition_help(pos="550")]
      private var mAdPositionType:int;
      [__go_to_definition_help(pos="591")]
      private var mAdPosition:int;
      [__go_to_definition_help(pos="628")]
      private var mAdPositionCoord:Array;
      [__go_to_definition_help(pos="672")]
      private var mAdMobId:String;
      [__go_to_definition_help(pos="709")]
      private var mAutoShow:Boolean;

      {
         POS_RELATIVE = 0;
         POS_ABSOLUTE = 1;
      }

      public function AdMobBanner(_adSize:int, _adPositionType:int, _adPosition:Array, _bannerId:String, _adMobId:String, _autoShow:Boolean)
      {
         super();
         this.mBannerId = _bannerId;
         this.mAdSize = _adSize;
         this.mAdPositionType = _adPositionType;
         if(this.mAdPositionType == POS_RELATIVE)
         {
            this.mAdPosition = _adPosition[0];
         }
         if(this.mAdPositionType == POS_ABSOLUTE)
         {
            this.mAdPositionCoord = _adPosition;
         }
         this.mAdMobId = _adMobId;
         this.mAutoShow = _autoShow;
      }

      [__go_to_definition_help(pos="788")]
      public function get bannerId():String
      {
         return this.mBannerId;
      }

      [__go_to_definition_help(pos="892")]
      public function get adPositionType():int
      {
         return this.mAdPositionType;
      }

      [__go_to_definition_help(pos="1010")]
      public function get adPosition():int
      {
         return this.mAdPosition;
      }

      [__go_to_definition_help(pos="1116")]
      public function get adPositionCoord():Array
      {
         return this.mAdPositionCoord;
      }

      [__go_to_definition_help(pos="1234")]
      public function get autoShow():Boolean
      {
         return this.mAutoShow;
      }
   }
}
