// swf-toolkit: abc=2 class=0
package com.admob
{
   public final class ScreenSize
   {

      [__go_to_definition_help(pos="83")]
      public var width:int;
      [__go_to_definition_help(pos="114")]
      public var height:int;

      public function ScreenSize(width:int = 0, height:int = 0)
      {
         super();
         this.width = width;
         this.height = height;
      }
   }
}
