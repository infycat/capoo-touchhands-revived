// swf-toolkit: abc=3 class=0
package com.admob
{
   public class AdMobFunctions
   {

      [__go_to_definition_help(pos="362")]
      public static const BANNER_CREATE:String = "createBanner";
      [__go_to_definition_help(pos="431")]
      public static const BANNER_CREATE_ABSOLUTE:String = "createBannerAbsolute";
      [__go_to_definition_help(pos="515")]
      public static const BANNER_SHOW:String = "showBanner";
      [__go_to_definition_help(pos="581")]
      public static const BANNER_HIDE:String = "hideBanner";
      [__go_to_definition_help(pos="647")]
      public static const BANNER_REMOVE:String = "removeBanner";
      [__go_to_definition_help(pos="716")]
      public static const INTERSTITIAL_CREATE:String = "createInterstitial";
      [__go_to_definition_help(pos="796")]
      public static const INTERSTITIAL_REMOVE:String = "removeInterstitial";
      [__go_to_definition_help(pos="876")]
      public static const INTERSTITIAL_SHOW:String = "showInterstitial";
      [__go_to_definition_help(pos="952")]
      public static const INTERSTITIAL_CACHE:String = "cacheInterstitial";
      [__go_to_definition_help(pos="1030")]
      public static const INTERSTITIAL_IS_LOADED:String = "isInterstitialLoaded";
      [__go_to_definition_help(pos="1114")]
      public static const SET_MODE:String = "setMode";
      [__go_to_definition_help(pos="1175")]
      public static const SET_TEST_DEVICE_ID:String = "setTestDeviceID";
      [__go_to_definition_help(pos="1251")]
      public static const SET_VERBOSE:String = "setVerbose";
      [__go_to_definition_help(pos="1317")]
      public static const SET_GENDER:String = "setGender";
      [__go_to_definition_help(pos="1381")]
      public static const SET_BIRTHYEAR:String = "setBirthYear";
      [__go_to_definition_help(pos="1450")]
      public static const SET_BIRTHMONTH:String = "setBirthMonth";
      [__go_to_definition_help(pos="1521")]
      public static const SET_BIRTHDAY:String = "setBirthDay";
      [__go_to_definition_help(pos="1589")]
      public static const SET_CDT:String = "setCDT";
      [__go_to_definition_help(pos="1648")]
      public static const BANNER_MOVE:String = "moveBanner";
      [__go_to_definition_help(pos="1705")]
      public static const BANNER_ROTATE:String = "rotateBanner";
      [__go_to_definition_help(pos="1766")]
      public static const GET_AD_SIZE:String = "getAdSize";
      [__go_to_definition_help(pos="1822")]
      public static const GET_SCREEN_SIZE:String = "getScreenSize";

      {
         BANNER_CREATE = "createBanner";
         BANNER_CREATE_ABSOLUTE = "createBannerAbsolute";
         BANNER_SHOW = "showBanner";
         BANNER_HIDE = "hideBanner";
         BANNER_REMOVE = "removeBanner";
         INTERSTITIAL_CREATE = "createInterstitial";
         INTERSTITIAL_REMOVE = "removeInterstitial";
         INTERSTITIAL_SHOW = "showInterstitial";
         INTERSTITIAL_CACHE = "cacheInterstitial";
         INTERSTITIAL_IS_LOADED = "isInterstitialLoaded";
         SET_MODE = "setMode";
         SET_TEST_DEVICE_ID = "setTestDeviceID";
         SET_VERBOSE = "setVerbose";
         SET_GENDER = "setGender";
         SET_BIRTHYEAR = "setBirthYear";
         SET_BIRTHMONTH = "setBirthMonth";
         SET_BIRTHDAY = "setBirthDay";
         SET_CDT = "setCDT";
         BANNER_MOVE = "moveBanner";
         BANNER_ROTATE = "rotateBanner";
         GET_AD_SIZE = "getAdSize";
         GET_SCREEN_SIZE = "getScreenSize";
      }

      public function AdMobFunctions()
      {
      }
   }
}
