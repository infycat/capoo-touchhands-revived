// swf-toolkit: abc=5 class=0
package com.admob
{
   import flash.events.Event;

   public class AdMobEvent extends Event
   {

      [__go_to_definition_help(pos="415")]
      public static const BANNER_LOADED:String = "onBannerLoaded";
      [__go_to_definition_help(pos="488")]
      public static const BANNER_FAILED_TO_LOAD:String = "onBannerFailedToLoad";
      [__go_to_definition_help(pos="573")]
      public static const BANNER_AD_OPENED:String = "onBannerAdOpened";
      [__go_to_definition_help(pos="651")]
      public static const BANNER_AD_CLOSED:String = "onBannerAdClosed";
      [__go_to_definition_help(pos="729")]
      public static const BANNER_LEFT_APPLICATION:String = "onBannerLeftApplication";
      [__go_to_definition_help(pos="819")]
      public static const INTERSTITIAL_LOADED:String = "onInterstitialLoaded";
      [__go_to_definition_help(pos="903")]
      public static const INTERSTITIAL_FAILED_TO_LOAD:String = "onInterstitialFailedToLoad";
      [__go_to_definition_help(pos="999")]
      public static const INTERSTITIAL_AD_OPENED:String = "onInterstitialAdOpened";
      [__go_to_definition_help(pos="1087")]
      public static const INTERSTITIAL_AD_CLOSED:String = "onInterstitialAdClosed";
      [__go_to_definition_help(pos="1175")]
      public static const INTERSTITIAL_LEFT_APPLICATION:String = "onInterstitialLeftApplication";

      [__go_to_definition_help(pos="1305")]
      public var data:String;

      {
         BANNER_LOADED = "onBannerLoaded";
         BANNER_FAILED_TO_LOAD = "onBannerFailedToLoad";
         BANNER_AD_OPENED = "onBannerAdOpened";
         BANNER_AD_CLOSED = "onBannerAdClosed";
         BANNER_LEFT_APPLICATION = "onBannerLeftApplication";
         INTERSTITIAL_LOADED = "onInterstitialLoaded";
         INTERSTITIAL_FAILED_TO_LOAD = "onInterstitialFailedToLoad";
         INTERSTITIAL_AD_OPENED = "onInterstitialAdOpened";
         INTERSTITIAL_AD_CLOSED = "onInterstitialAdClosed";
         INTERSTITIAL_LEFT_APPLICATION = "onInterstitialLeftApplication";
      }

      public function AdMobEvent(type:String, data:String = null, bubbles:Boolean = false, cancelable:Boolean = false)
      {
         this.data = data;
         super(type, bubbles, cancelable);
      }
   }
}
