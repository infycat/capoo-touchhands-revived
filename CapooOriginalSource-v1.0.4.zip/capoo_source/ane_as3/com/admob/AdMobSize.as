// swf-toolkit: abc=8 class=0
package com.admob
{
   public class AdMobSize
   {

      [__go_to_definition_help(pos="199")]
      public static const BANNER:int = 0;
      [__go_to_definition_help(pos="246")]
      public static const MEDIUM_RECTANGLE:int = 1;
      [__go_to_definition_help(pos="300")]
      public static const FULL_BANNER:int = 2;
      [__go_to_definition_help(pos="351")]
      public static const LEADERBOARD:int = 3;
      [__go_to_definition_help(pos="396")]
      public static const WIDE_SKYSCRAPER:int = 4;
      [__go_to_definition_help(pos="450")]
      public static const SMART_BANNER:int = 5;
      [__go_to_definition_help(pos="501")]
      public static const SMART_BANNER_PORT:int = 6;
      [__go_to_definition_help(pos="556")]
      public static const SMART_BANNER_LAND:int = 7;
      [__go_to_definition_help(pos="611")]
      public static const LARGE_BANNER:int = 8;

      {
         BANNER = 0;
         MEDIUM_RECTANGLE = 1;
         FULL_BANNER = 2;
         LEADERBOARD = 3;
         WIDE_SKYSCRAPER = 4;
         SMART_BANNER = 5;
         SMART_BANNER_PORT = 6;
         SMART_BANNER_LAND = 7;
         LARGE_BANNER = 8;
      }

      public function AdMobSize()
      {
      }

      [__go_to_definition_help(pos="658")]
      public static function typeSize(adMobSizeType:int):AdSize
      {
         var _loc2_ = adMobSizeType;
         switch(BANNER !== _loc2_ ? MEDIUM_RECTANGLE !== _loc2_ ? FULL_BANNER !== _loc2_ ? LEADERBOARD !== _loc2_ ? WIDE_SKYSCRAPER !== _loc2_ ? SMART_BANNER !== _loc2_ ? SMART_BANNER_PORT !== _loc2_ ? SMART_BANNER_LAND !== _loc2_ ? LARGE_BANNER !== _loc2_ ? true ? 9 : 9 : 8 : 7 : 6 : 5 : 4 : 3 : 2 : 1 : 0)
         {
            case 0:
               return new AdSize(320, 50);
            case 1:
               return new AdSize(320, 250);
            case 2:
               return new AdSize(468, 60);
            case 3:
               return new AdSize(728, 90);
            case 4:
               return new AdSize(160, 600);
            case 5:
               return new AdSize(-1, -2);
            case 6:
               return new AdSize(-1, -2);
            case 7:
               return new AdSize(-1, -2);
            case 8:
               return new AdSize(320, 100);
            case 9:
            default:
               return new AdSize(320, 50);
         }
      }
   }
}
