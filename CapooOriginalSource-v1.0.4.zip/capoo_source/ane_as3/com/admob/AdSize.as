// swf-toolkit: abc=1 class=0
package com.admob
{
   public final class AdSize
   {

      [__go_to_definition_help(pos="77")]
      public var width:int;
      [__go_to_definition_help(pos="108")]
      public var height:int;

      public function AdSize(width:int = 0, height:int = 0)
      {
         super();
         this.width = width;
         this.height = height;
      }
   }
}
