// swf-toolkit: abc=6 class=0
package com.admob
{
   public class AdMobPosition
   {

      [__go_to_definition_help(pos="359")]
      public static const TOP_LEFT:int = 1;
      [__go_to_definition_help(pos="406")]
      public static const TOP_CENTER:int = 2;
      [__go_to_definition_help(pos="455")]
      public static const TOP_RIGHT:int = 3;
      [__go_to_definition_help(pos="503")]
      public static const MIDDLE_LEFT:int = 4;
      [__go_to_definition_help(pos="553")]
      public static const MIDDLE_CENTER:int = 5;
      [__go_to_definition_help(pos="604")]
      public static const MIDDLE_RIGHT:int = 6;
      [__go_to_definition_help(pos="654")]
      public static const BOTTOM_LEFT:int = 7;
      [__go_to_definition_help(pos="704")]
      public static const BOTTOM_CENTER:int = 8;
      [__go_to_definition_help(pos="755")]
      public static const BOTTOM_RIGHT:int = 9;

      {
         TOP_LEFT = 1;
         TOP_CENTER = 2;
         TOP_RIGHT = 3;
         MIDDLE_LEFT = 4;
         MIDDLE_CENTER = 5;
         MIDDLE_RIGHT = 6;
         BOTTOM_LEFT = 7;
         BOTTOM_CENTER = 8;
         BOTTOM_RIGHT = 9;
      }

      public function AdMobPosition()
      {
      }
   }
}
