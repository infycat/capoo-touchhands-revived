package capoo_fla
{
   import flash.display.MovieClip;
   import flash.display.SimpleButton;
   import flash.events.MouseEvent;
   import flash.text.TextField;

   public dynamic class 彈跳訊息_entername_55 extends MovieClip
   {

      public var newname:TextField;
      public var ok:SimpleButton;

      public function 彈跳訊息_entername_55()
      {
         super();
         addFrameScript(0, this.frame1, 5, this.frame6);
      }

      public function go_again(param1:MouseEvent):void
      {
         if(this.newname.text != "")
         {
            root["over"] = true;
            this.x = -1000;
            root["role"][root["gsit"]][1] = this.newname.text;
            root["lastname"] = this.newname.text;
         }
      }

      internal function frame1():*
      {
         stop();
      }

      internal function frame6():*
      {
         stop();
         this.newname.text = String(root["lastname"]);
         this.ok.addEventListener(MouseEvent.CLICK, this.go_again);
      }
   }
}
