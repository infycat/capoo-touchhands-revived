package capoo_fla
{
   import flash.display.MovieClip;

   public dynamic class 經驗值_色塊_14 extends MovieClip
   {

      public function 經驗值_色塊_14()
      {
         super();
         addFrameScript(0, this.frame1);
      }

      internal function frame1():*
      {
         stop();
      }
   }
}
