package capoo_fla
{
   import flash.display.MovieClip;

   public dynamic class combo_33 extends MovieClip
   {

      public var bo:MovieClip;

      public function combo_33()
      {
         super();
         addFrameScript(0, this.frame1, 1, this.frame2);
      }

      internal function frame1():*
      {
         stop();
      }

      internal function frame2():*
      {
         this.bo.bo_txt.text = String(root["hit_sum"]);
      }
   }
}
