package capoo_fla
{
   import flash.display.MovieClip;

   public dynamic class 新咖波_12 extends MovieClip
   {

      public function 新咖波_12()
      {
         super();
         addFrameScript(17, this.frame18);
      }

      internal function frame18():*
      {
         gotoAndPlay(1);
      }
   }
}
