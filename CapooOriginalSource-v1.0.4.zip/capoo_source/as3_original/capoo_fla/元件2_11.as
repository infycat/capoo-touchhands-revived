package capoo_fla
{
   import flash.display.MovieClip;

   public dynamic class 元件2_11 extends MovieClip
   {

      public var capo:MovieClip;

      public function 元件2_11()
      {
         super();
         addFrameScript(0, this.frame1, 9, this.frame10);
      }

      internal function frame1():*
      {
         stop();
      }

      internal function frame10():*
      {
         stop();
      }
   }
}
