package capoo_fla
{
   import flash.display.MovieClip;

   public dynamic class 過關延遲時間_58 extends MovieClip
   {

      public var kk:Boolean;

      public function 過關延遲時間_58()
      {
         super();
         addFrameScript(0, this.frame1, 1, this.frame2, 9, this.frame10);
      }

      internal function frame1():*
      {
         stop();
         this.kk = false;
      }

      internal function frame2():*
      {
         this.kk = false;
      }

      internal function frame10():*
      {
         this.kk = true;
         stop();
      }
   }
}
