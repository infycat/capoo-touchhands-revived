package capoo_fla
{
   import flash.display.MovieClip;

   public dynamic class 擊掌特效_35 extends MovieClip
   {

      public function 擊掌特效_35()
      {
         super();
         addFrameScript(0, this.frame1, 5, this.frame6, 10, this.frame11, 15, this.frame16);
      }

      internal function frame1():*
      {
         stop();
      }

      internal function frame6():*
      {
         gotoAndStop("top");
      }

      internal function frame11():*
      {
         gotoAndStop("top");
      }

      internal function frame16():*
      {
         gotoAndStop("top");
      }
   }
}
