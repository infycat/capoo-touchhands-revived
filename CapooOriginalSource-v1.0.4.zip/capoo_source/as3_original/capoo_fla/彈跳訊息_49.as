package capoo_fla
{
   import flash.display.MovieClip;
   import flash.events.MouseEvent;

   public dynamic class 彈跳訊息_49 extends MovieClip
   {

      public var ok:MovieClip;

      public function 彈跳訊息_49()
      {
         super();
         addFrameScript(0, this.frame1, 5, this.frame6);
      }

      public function go_again(param1:MouseEvent):void
      {
         root["over"] = true;
         this.x = -1000;
      }

      internal function frame1():*
      {
         stop();
      }

      internal function frame6():*
      {
         stop();
         this.ok.addEventListener(MouseEvent.CLICK, this.go_again);
      }
   }
}
