package capoo_fla
{
   import flash.display.MovieClip;
   import flash.events.Event;

   public dynamic class 元件3_56 extends MovieClip
   {

      public var late:MovieClip;
      public var ss:int;
      public var trnego:Boolean;

      public function 元件3_56()
      {
         super();
         addFrameScript(0, this.frame1);
      }

      public function score_go(param1:Event):*
      {
         if(this.ss == 1)
         {
            if(root["hit_sum"] < 31)
            {
               removeEventListener(Event.ENTER_FRAME, this.score_go);
               root["over"] = true;
            }
            else if(this.trnego == false)
            {
               this.late.gotoAndPlay("go");
               this.trnego = true;
            }
            else if(this.late.kk == true)
            {
               this.trnego = false;
               this.late.kk = false;
               this.late.gotoAndStop(1);
               gotoAndStop(2);
               this.ss = 2;
            }
         }
         else if(this.ss == 2)
         {
            if(root["hit_sum"] < 71)
            {
               removeEventListener(Event.ENTER_FRAME, this.score_go);
               root["over"] = true;
            }
            else if(this.trnego == false)
            {
               this.late.gotoAndPlay("go");
               this.trnego = true;
            }
            else if(this.late.kk == true)
            {
               this.trnego = false;
               this.late.kk = false;
               this.late.gotoAndStop(1);
               gotoAndStop(3);
               this.ss = 3;
            }
         }
         else if(this.ss == 3)
         {
            if(root["hit_sum"] < 131)
            {
               removeEventListener(Event.ENTER_FRAME, this.score_go);
               root["over"] = true;
            }
            else if(this.trnego == false)
            {
               this.late.gotoAndPlay("go");
               this.trnego = true;
            }
            else if(this.late.kk == true)
            {
               this.trnego = false;
               this.late.kk = false;
               this.late.gotoAndStop(1);
               gotoAndStop(4);
               this.ss = 4;
            }
         }
         else if(this.ss == 4)
         {
            if(root["hit_sum"] < 201)
            {
               removeEventListener(Event.ENTER_FRAME, this.score_go);
               root["over"] = true;
            }
            else if(this.trnego == false)
            {
               this.late.gotoAndPlay("go");
               this.trnego = true;
            }
            else if(this.late.kk == true)
            {
               this.trnego = false;
               this.late.kk = false;
               this.late.gotoAndStop(1);
               gotoAndStop(5);
               this.ss = 5;
            }
         }
         else
         {
            removeEventListener(Event.ENTER_FRAME, this.score_go);
            root["over"] = true;
         }
         if(root["over"] != true ? root["over"] == true : root["getnew"] == true)
         {
            root["over"] = false;
            root["new_name"].x = 240;
            root["new_name"].y = 400;
            root["new_name"].play();
         }
      }

      internal function frame1():*
      {
         stop();
         this.ss = 1;
         this.trnego = false;
         addEventListener(Event.ENTER_FRAME, this.score_go);
      }
   }
}
