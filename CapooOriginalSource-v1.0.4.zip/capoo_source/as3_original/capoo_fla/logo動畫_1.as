package capoo_fla
{
   import flash.display.MovieClip;

   public dynamic class logo動畫_1 extends MovieClip
   {

      public function logo動畫_1()
      {
         super();
         addFrameScript(29, this.frame30);
      }

      internal function frame30():*
      {
         MovieClip(this.parent).gotoAndStop("top");
      }
   }
}
