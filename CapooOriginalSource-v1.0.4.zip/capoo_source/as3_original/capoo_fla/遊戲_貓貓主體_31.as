package capoo_fla
{
   import flash.display.MovieClip;

   public dynamic class 遊戲_貓貓主體_31 extends MovieClip
   {

      public var L1_mc:MovieClip;
      public var L2_mc:MovieClip;
      public var L3_mc:MovieClip;
      public var R1_mc:MovieClip;
      public var R2_mc:MovieClip;
      public var R3_mc:MovieClip;

      public function 遊戲_貓貓主體_31()
      {
         super();
         addFrameScript(0, this.frame1, 3, this.frame4, 19, this.frame20);
      }

      internal function frame1():*
      {
         stop();
      }

      internal function frame4():*
      {
         root["total_time"] = 0;
         root["myTimer"].stop();
         root["t_mc"].stop();
         root["hit"] = false;
      }

      internal function frame20():*
      {
         stop();
         root["win"] = true;
         root["timer_txt"].text = String(root["total_time"]);
      }
   }
}
