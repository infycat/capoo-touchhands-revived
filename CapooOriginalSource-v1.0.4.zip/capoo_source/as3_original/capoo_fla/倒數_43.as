package capoo_fla
{
   import flash.display.MovieClip;

   public dynamic class 倒數_43 extends MovieClip
   {

      public function 倒數_43()
      {
         super();
         addFrameScript(0, this.frame1, 29, this.frame30);
      }

      internal function frame1():*
      {
         stop();
      }

      internal function frame30():*
      {
         this.x = -1000;
         root["game_start"] = true;
         stop();
      }
   }
}
