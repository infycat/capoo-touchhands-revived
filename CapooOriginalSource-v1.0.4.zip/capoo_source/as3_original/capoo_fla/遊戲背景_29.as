package capoo_fla
{
   import flash.display.MovieClip;

   public dynamic class 遊戲背景_29 extends MovieClip
   {

      public var kk:int;

      public function 遊戲背景_29()
      {
         super();
         addFrameScript(0, this.frame1, 1, this.frame2, 2, this.frame3, 3, this.frame4, 4, this.frame5);
      }

      internal function frame1():*
      {
         stop();
         this.kk = 1;
      }

      internal function frame2():*
      {
         this.kk = 2;
      }

      internal function frame3():*
      {
         this.kk = 3;
      }

      internal function frame4():*
      {
         this.kk = 4;
      }

      internal function frame5():*
      {
         this.kk = 5;
      }
   }
}
