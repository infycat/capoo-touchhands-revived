package capoo_fla
{
   import flash.display.MovieClip;

   public dynamic class 貓貓網上爬_16 extends MovieClip
   {

      public function 貓貓網上爬_16()
      {
         super();
         addFrameScript(45, this.frame46);
      }

      internal function frame46():*
      {
         MovieClip(this.parent).gotoAndStop("start");
      }
   }
}
