package capoo_fla
{
   import flash.display.MovieClip;

   public dynamic class 貓貓圖1_17 extends MovieClip
   {

      public function 貓貓圖1_17()
      {
         super();
         addFrameScript(26, this.frame27);
      }

      internal function frame27():*
      {
         stop();
      }
   }
}
