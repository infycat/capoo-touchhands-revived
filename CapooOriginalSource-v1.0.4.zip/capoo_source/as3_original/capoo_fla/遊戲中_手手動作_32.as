package capoo_fla
{
   import flash.display.MovieClip;

   public dynamic class 遊戲中_手手動作_32 extends MovieClip
   {

      public function 遊戲中_手手動作_32()
      {
         super();
         addFrameScript(0, this.frame1, 1, this.frame2, 5, this.frame6, 13, this.frame14);
      }

      internal function frame1():*
      {
         stop();
      }

      internal function frame2():*
      {
         root["hit"] = true;
      }

      internal function frame6():*
      {
         stop();
      }

      internal function frame14():*
      {
         gotoAndPlay("up");
      }
   }
}
