# 遊戲邏輯解說（`src/capoo_fla/MainTimeline.as`）

全部遊戲邏輯都在 `MainTimeline` 這一個類別裡，用 `addFrameScript()` 把 8 段程式碼綁到時間軸的 8 個影格。
影格 = 畫面狀態，`gotoAndStop("menu" / "jump" / "rank" / ...)` 切換。

| 影格 | 標籤 | 內容 | 程式行 |
|---|---|---|---|
| frame1 | `top` | 初始化：資料庫、廣告、等級表、事件監聽 | 736–791 |
| frame2 | `menu` | 主選單（隱藏橫幅） | 792–812 |
| frame3 | `jump` | 遊戲中（顯示橫幅、啟動計時器） | 813–846 |
| frame4 | `rank` | 排行榜（顯示橫幅） | 847–880 |
| frame5 | `name` | 輸入名字（隱藏橫幅） | 881–900 |
| frame6 | `start` | 倒數 3-2-1 | 901–931 |
| frame7 | `result` | 結算：算分、更新 DB、播插屏 | 932–988 |
| frame8 | `end` | 結束畫面（顯示橫幅） | 989–1013 |

---

## 1. 玩法

* 畫面中央是貓貓（`capoo`），左右各 3 隻手（`hand[1..6]`），同時只會舉起一隻手。
* 玩家點**舉起的那隻手**：`L1chk/L2chk/L3chk`（左手 1–3）、`R1chk/R2chk/R3chk`（右手 4–6）。
* 點對 → `score += combos`、`hit_sum++`、`total_time += add_time`，然後隨機舉起下一隻手。
* 點錯 → `hit = false`，貓貓播放 `atk` 動畫（漏接，連段歸零）。
* 每局 100 秒（`total_time`），時間到 → `win = true` → `winTimer` 觸發 → 進結算。

**連段倍率**（依累計命中數 `hit_sum` 切換，寫在 `actor_go` :396–421）：

| 累計命中 | combo 狀態 | 每次得分 `combos` | 背景 |
|---|---|---|---|
| 0–19 | `hita` | **51** | a |
| 20–49 | `hitb` | **203** | b |
| 50–99 | `hitc` | **302** | c |
| ≥100 | （維持 hitc） | 302 | d |
| ≥200 | | 302 | e |

**加時**：`hit_sum > 150` 時每次命中 `+1` 秒，否則 `+2` 秒（`actor_go` :422–433）。
上限 `all_time`（初始 100 秒），`myTimerFunc` 會夾住。

## 2. 本機資料庫（排行榜）

* 路徑：`File.applicationStorageDirectory/capoo.db`（AIR 的 app storage，Android 上約在
  `/data/data/air.capoo/Local Store/`）
* 表：`gamed(name1..name5, score1..score5, dstatus)`

| 方法 | 行 | SQL |
|---|---|---|
| `dbStatement`（建表） | 153 | `CREATE TABLE IF NOT EXISTS gamed(name1 TEXT,score1 INTEGER, …, dstatus INTEGER)` |
| `SelectGameDResult`（讀） | 166 起 | `SELECT * FROM gamed` |
| `AddGameRow`（寫入一列） | 193 | `INSERT INTO gamed VALUES('…','…',…,1)` |
| `UpdateGameDQuery`（改單欄） | 254 | `UPDATE gamed SET <欄位>='<值>' WHERE dstatus=<n>` |

結算時 `frame7`（:716–725）把畫面上的名字/分數逐欄 UPDATE 回資料庫，
`frame8`（:989–1013）再讀出來顯示前 5 名。

> 注意：SQL 是**字串拼接**的（沒有參數化），玩家名字若含單引號 `'` 會讓語句壞掉——
> 這是原版就有的 bug，見 `docs/PATCHES.md` 的修法。

## 3. 廣告（ANE `com.admob.ane`）

初始化在 `frame1`（:754–772）：

```as3
this.banner_id = "ca-app-pub-6658873732957400/3889285977";
this.full_id   = "ca-app-pub-6658873732957400/2272951977";
adMobManager.setMode(AdMobMode.TEST_MODE, false);
adMobManager.setVerbose(true);
adMobManager.setGender(AdMobGender.MALE);
adMobManager.setBirthYear(1996); …Month(1); …Day(24);
adMobManager.setCDT(true);
adMobManager.createBanner(AdMobSize.BANNER, AdMobPosition.BOTTOM_CENTER, "BottomBanner", null, true);
adMobManager.createInterstitial(null, false);
```

| 時機 | 動作 |
|---|---|
| frame2 / frame5 | `hideBanner("BottomBanner")` |
| frame3 / frame4 / frame8 | `showBanner("BottomBanner")` |
| frame7（結算，只播一次） | `showInterstitial()`（先 `isInterstitialLoaded()` 檢查） |

## 4. 等級 / 經驗值

`frame1`（:774–784）定義 `level_exp` 陣列（升到第 N 級所需經驗）與 `level`，
`frame3`（:813–846）命中時累加 `level_exp`，滿了就 `level++` 並播放升級動畫。

## 5. 其他

* `handleKeys`（:284）：處理 BACK / MENU / HOME 鍵（BACK 依 `curr` 狀態返回或離開）
* `capoo_hit`（:347）：點貓貓 → 播放 `hit` 動畫（純互動，不計分）
* `myTimerFunc`（:352）：每秒 tick，更新時間條 `time_line` 與數字 `timer_txt`
* `actor_go`（:375）：每幀驅動（舉手、換背景、判斷勝負）

## 6. 狀態變數一覽

| 變數 | 意義 |
|---|---|
| `score` | 本局分數 |
| `hit_sum` | 累計命中數（決定 combo 等級） |
| `combo` / `combos` | 目前 combo 狀態字串 / 每次得分 |
| `total_time` / `all_time` | 剩餘時間 / 時間上限 |
| `add_time` | 每次命中加時 |
| `hit_nmbL` / `hit_nmbR` | 目前舉起的手（1–3 左、4–6 右） |
| `hit` / `win` / `game_start` | 可否命中 / 是否結束 / 是否開局 |
| `curr` | 目前影格編號（給 BACK 鍵判斷用） |
| `gname` / `gscr` | 輸入的名字 / 本局分數（寫入 DB 用） |
