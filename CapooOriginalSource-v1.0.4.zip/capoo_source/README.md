# capoo 1.0.1 — 完整原始碼包

## 這是什麼
從 `capoo_1.0.1.apk`（Adobe AIR 15 / Flash AS3）反編譯出來的完整遊戲原始碼。

## 檔案說明

### as3_original/  ← 最初的源碼（反編譯還原）
`capoo_fla/` 下 17 個 AS3 類別，共 1,576 行，這是「原版」邏輯：
- `MainTimeline.as`（1,015 行）— 全部遊戲邏輯：SQLite 排行榜、AdMob 廣告、計分、combo、等級、輸入名字、結局
- 其餘 16 個是時間軸上的元件類別（貓咪、手、背景、倒數、彈跳訊息…）

> 這些檔案是由 SWF 的 ABC 位元組碼反編譯而來，變數名多為 `_loc1_`、`this.xxx` 形式，
> 但**可以再用 swf-toolkit 編譯回 SWF**（已驗證：反編譯→重編譯→再反編譯，逐字相同）。

### as3_ruffle/  ← 手機模擬器（Ruffle）版
`MainTimeline_ruffle.as`（894 行）— 為了在沒有 AIR runtime 的環境跑，做了兩處改動：
1. 移除 `flash.data.*`（SQLite），排行榜改成記憶體陣列 `this.role`
2. 移除 AdMob ANE 呼叫
其餘邏輯與原版一致。

### ane_as3/  ← 廣告外掛介面
`com/admob/` 下 9 個類別：AdMobManager、AdMobFunctions（22 個橋接函式）、AdMobEvent、AdMobSize、AdMobPosition、AdSize、ScreenSize、AdMobBanner、AdMobEvent。

### swf/capoo.swf
原始編譯產物（7,318,593 B，CWS/zlib，SWF v26，480×800，15fps，616 tags）。
如果要重新編譯 AS3 進這個 SWF：
```bash
swf-toolkit import-as3 capoo.swf as3_original/capoo_fla out.swf
```

### app.xml
AIR 應用描述檔（id=capoo、version=1.0.1、initialWindow content=capoo.swf、com.admob.ane 擴展）。

### game_logic.md
遊戲邏輯逐段解說（影格流程、計分公式、資料庫結構、廣告時機）。

## 重建路徑
- **手機 / 無 Java**：`proj/ruffle_port/`（WebView + Ruffle）
- **電腦 + AIR SDK**：`proj/kit/`（換新 AIR runtime 重打包）

## 版權
遊戲內容（咖波角色、美術、音效）版權屬原作者；本包僅供學習與個人研究。
