package capoo_fla
{
   import flash.desktop.NativeApplication;
   import flash.desktop.SystemIdleMode;
   import flash.display.MovieClip;
   import flash.display.SimpleButton;
   import flash.events.Event;
   import flash.events.KeyboardEvent;
   import flash.events.MouseEvent;
   import flash.events.TimerEvent;
   import flash.events.TouchEvent;
   import flash.media.SoundMixer;
   import flash.media.SoundTransform;
   import flash.text.TextField;
   import flash.ui.Keyboard;
   import flash.ui.Multitouch;
   import flash.ui.MultitouchInputMode;
   import flash.utils.Timer;

   public dynamic class MainTimeline extends MovieClip
   {

      public var GO:SimpleButton;
      public var L1_but:MovieClip;
      public var L2_but:MovieClip;
      public var L3_but:MovieClip;
      public var R1_but:MovieClip;
      public var R2_but:MovieClip;
      public var R3_but:MovieClip;
      public var adexp_txt:TextField;
      public var again:SimpleButton;
      public var back_menu:SimpleButton;
      public var bg_mc:MovieClip;
      public var bom_mc:MovieClip;
      public var capoo:MovieClip;
      public var comb_mc:MovieClip;
      public var down_mc:MovieClip;
      public var exp_mc:MovieClip;
      public var exp_txt:TextField;
      public var go_menu:MovieClip;
      public var head_mc:MovieClip;
      public var hit_point:TextField;
      public var level_txt:TextField;
      public var level_up:MovieClip;
      public var meet_mc:MovieClip;
      public var name1:TextField;
      public var name2:TextField;
      public var name3:TextField;
      public var name4:TextField;
      public var name5:TextField;
      public var new_name:MovieClip;
      public var rank:SimpleButton;
      public var score_txt:TextField;
      public var scr1:TextField;
      public var scr2:TextField;
      public var scr3:TextField;
      public var scr4:TextField;
      public var scr5:TextField;
      public var t_mc:MovieClip;
      public var time_line:MovieClip;
      public var timer_txt:TextField;
      public var role:*;
      public var r:*;
      public var lastname:String;
      public var dbt:Boolean;
      public var db:File;
      public var conn:*;
      public var echo:String;
      public var banner_id:String;
      public var full_id:String;
      public var adMobManager:*;
      public var isShow:Boolean;
      public var level:int;
      public var exp_n:int;
      public var exp_h:int;
      public var level_max:int;
      public var level_exp:Array;
      public var curr:int;
      public var get_down:Boolean;
      public var lines:int;
      public var hand:Array;
      public var win:Boolean;
      public var game_start:Boolean;
      public var hit:Boolean;
      public var hit_nmbL:int;
      public var hit_nmbR:int;
      public var hit_sum:int;
      public var score:int;
      public var combo:String;
      public var combos:int;
      public var total_time:int;
      public var all_time:int;
      public var add_time:int;
      public var myTimer:Timer;
      public var winTimer:*;
      public var ggg:int;
      public var skip_b:Boolean;
      public var over:Boolean;
      public var sco:int;
      public var add_sco:int;
      public var add_exp:int;
      public var all_exp:int;
      public var now_exp:int;
      public var gg_exp:int;
      public var lv_up:Boolean;
      public var getnew:Boolean;
      public var gname:String;
      public var gscr:int;
      public var gsit:int;
      public var ss:*;
      public var sn:String;
      public var sc:int;

      public function MainTimeline()
      {
         super();
         addFrameScript(0, this.frame1, 1, this.frame2, 2, this.frame3, 3, this.frame4, 4, this.frame5, 5, this.frame6, 6, this.frame7, 7, this.frame8);
      }

      public function onOpenHandler(param1:*):void
      {
      }

      public function onOpenErrorHandler(param1:*):void
      {
      }

      public function Query(param1:String, param2:Function = null, param3:Function = null):void
      {
      }

      public function AddGameRow(param1:String, param2:String, param3:String, param4:String, param5:String, param6:String, param7:String, param8:String, param9:String, param10:String, param11:String):void
      {
         if(this.role == null)
         {
            return;
         }
         this.role[1][1] = param1;
         this.role[1][2] = int(param2);
         this.role[2][1] = param3;
         this.role[2][2] = int(param4);
         this.role[3][1] = param5;
         this.role[3][2] = int(param6);
         this.role[4][1] = param7;
         this.role[4][2] = int(param8);
         this.role[5][1] = param9;
         this.role[5][2] = int(param10);
      }

      public function AddGameRowResult(param1:*):void
      {
      }

      public function AddGameRowFault(param1:*):void
      {
      }

      public function SelectGameDResult(param1:*):void
      {
      }

      public function SelectGameDFault(param1:*):void
      {
      }

      public function UpdateGameDQuery(param1:String, param2:String, param3:String):void
      {
         var _loc4_:int = int(param3);
         if(_loc4_ >= 1 && _loc4_ <= 5 && this.role != null)
         {
            this.role[_loc4_][1] = param2;
         }
      }

      public function RunUpdateResult(param1:*):void
      {
      }

      public function RunUpdateFault(param1:*):void
      {
      }


      public function handleActivate(param1:Event):void
      {
         NativeApplication.nativeApplication.systemIdleMode = SystemIdleMode.KEEP_AWAKE;
         SoundMixer.soundTransform = new SoundTransform(1);
      }

      public function handleDeactivate(param1:Event):void
      {
         SoundMixer.soundTransform = new SoundTransform(0);
      }

      public function handleKeys(param1:KeyboardEvent):void
      {
         if(param1.keyCode == Keyboard.BACK)
         {
            param1.preventDefault();
            if(this.curr == 1)
            {
               NativeApplication.nativeApplication.exit();
            }
            else if(this.curr == 2)
            {
               gotoAndStop("top");
            }
            else if(this.curr == 3)
            {
               gotoAndStop("menu");
            }
            else if(this.curr == 6)
            {
               gotoAndStop("menu");
            }
         }
         if(param1.keyCode == Keyboard.MENU)
         {
            param1.preventDefault();
         }
         if(param1.keyCode == Keyboard.HOME)
         {
            NativeApplication.nativeApplication.exit();
         }
      }

      public function handleKeyU(param1:KeyboardEvent):void
      {
         if(param1.keyCode == Keyboard.BACK)
         {
            this.get_down = false;
         }
         if(param1.keyCode == Keyboard.MENU)
         {
            this.get_down = false;
         }
         if(param1.keyCode == Keyboard.HOME)
         {
            this.get_down = false;
         }
      }

      public function go_menua(param1:MouseEvent):void
      {
         gotoAndStop("menu");
      }

      public function go_start(param1:MouseEvent):void
      {
         gotoAndStop("jump");
      }

      public function go_rank(param1:MouseEvent):void
      {
         gotoAndStop("rank");
      }

      public function capoo_hit(param1:MouseEvent):void
      {
         this.capoo.capo.gotoAndPlay("hit");
      }

      public function myTimerFunc(param1:Event):*
      {
         if(this.total_time > 0)
         {
            this.total_time--;
         }
         else
         {
            this.total_time = 0;
            this.myTimer.stop();
            this.t_mc.stop();
            this.hit = false;
            this.win = true;
         }
         if(this.total_time > this.all_time)
         {
            this.total_time = this.all_time;
         }
         var _loc2_:* = int(this.total_time * 100 / this.all_time) + 1;
         this.time_line.gotoAndStop(_loc2_);
         this.timer_txt.text = String(this.total_time);
      }

      public function actor_go(param1:Event):*
      {
         if(this.game_start == true)
         {
            this.t_mc.play();
            this.myTimer.start();
            this.hit_nmbL = Math.ceil(Math.random() * 3);
            this.hand[this.hit_nmbL].gotoAndPlay("up");
            this.hit_nmbR = Math.ceil(Math.random() * 3) + 3;
            this.hand[this.hit_nmbR].gotoAndPlay("up");
            if(this.hit_nmbL <= 3)
            {
               this.head_mc.gotoAndStop("left");
            }
            else
            {
               this.head_mc.gotoAndStop("right");
            }
            this.hit = true;
            this.game_start = false;
         }
         if(this.hit_sum >= 200 && this.bg_mc.kk == 4)
         {
            this.bg_mc.gotoAndStop("e");
         }
         else if(this.hit_sum >= 100 && this.bg_mc.kk == 3)
         {
            this.bg_mc.gotoAndStop("d");
         }
         else if(this.hit_sum >= 50 && this.combo == "hitb")
         {
            this.bg_mc.gotoAndStop("c");
            this.combo = "hitc";
            this.combos = 302;
         }
         else if(this.hit_sum >= 20 && this.combo == "hita")
         {
            this.bg_mc.gotoAndStop("b");
            this.combo = "hitb";
            this.combos = 203;
         }
         else if(this.hit_sum < 20 && this.combo != "hita")
         {
            this.bg_mc.gotoAndStop("a");
            this.combo = "hita";
            this.combos = 51;
         }
         if(this.hit_sum > 200)
         {
            this.add_time = 1;
         }
         else if(this.hit_sum > 150)
         {
            this.add_time = 1;
         }
         else
         {
            this.add_time = 2;
         }
         if(this.win == true)
         {
            this.winTimer.start();
         }
      }

      public function L1chk(param1:TouchEvent):void
      {
         if(this.hit == true)
         {
            if(this.hit_nmbL == 1)
            {
               this.hand[1].gotoAndStop("down");
               this.bom_mc.x = this.head_mc.x + this.hand[1].x;
               this.bom_mc.y = this.head_mc.y + this.hand[1].y;
               this.bom_mc.gotoAndPlay(this.combo);
               this.score += this.combos;
               this.hit_nmbL = Math.ceil(Math.random() * 2);
               if(this.hit_nmbL == 1)
               {
                  this.hit_nmbL = 2;
               }
               else
               {
                  this.hit_nmbL = 3;
               }
               this.hand[this.hit_nmbL].gotoAndPlay("up");
               if(this.hit_nmbL <= 3)
               {
                  this.head_mc.gotoAndStop("left");
               }
               else
               {
                  this.head_mc.gotoAndStop("right");
               }
               this.hit_sum++;
               this.total_time += this.add_time;
               this.comb_mc.gotoAndPlay("hit");
               this.hit = true;
            }
            else
            {
               this.hit = false;
               this.head_mc.gotoAndPlay("atk");
            }
         }
      }

      public function L2chk(param1:TouchEvent):void
      {
         if(this.hit == true)
         {
            if(this.hit_nmbL == 2)
            {
               this.hand[2].gotoAndStop("down");
               this.bom_mc.x = this.head_mc.x + this.hand[2].x;
               this.bom_mc.y = this.head_mc.y + this.hand[2].y;
               this.bom_mc.gotoAndPlay(this.combo);
               this.score += this.combos;
               this.hit_nmbL = Math.ceil(Math.random() * 2);
               if(this.hit_nmbL == 1)
               {
                  this.hit_nmbL = 1;
               }
               else
               {
                  this.hit_nmbL = 3;
               }
               this.hand[this.hit_nmbL].gotoAndPlay("up");
               if(this.hit_nmbL <= 3)
               {
                  this.head_mc.gotoAndStop("left");
               }
               else
               {
                  this.head_mc.gotoAndStop("right");
               }
               this.hit_sum++;
               this.total_time += this.add_time;
               this.comb_mc.gotoAndPlay("hit");
               this.hit = true;
            }
            else
            {
               this.hit = false;
               this.head_mc.gotoAndPlay("atk");
            }
         }
      }

      public function L3chk(param1:TouchEvent):void
      {
         if(this.hit == true)
         {
            if(this.hit_nmbL == 3)
            {
               this.hand[3].gotoAndStop("down");
               this.bom_mc.x = this.head_mc.x + this.hand[3].x;
               this.bom_mc.y = this.head_mc.y + this.hand[3].y;
               this.bom_mc.gotoAndPlay(this.combo);
               this.score += this.combos;
               this.hit_nmbL = Math.ceil(Math.random() * 2);
               if(this.hit_nmbL == 1)
               {
                  this.hit_nmbL = 1;
               }
               else
               {
                  this.hit_nmbL = 2;
               }
               this.hand[this.hit_nmbL].gotoAndPlay("up");
               if(this.hit_nmbL <= 3)
               {
                  this.head_mc.gotoAndStop("left");
               }
               else
               {
                  this.head_mc.gotoAndStop("right");
               }
               this.hit_sum++;
               this.total_time += this.add_time;
               this.comb_mc.gotoAndPlay("hit");
               this.hit = true;
            }
            else
            {
               this.hit = false;
               this.head_mc.gotoAndPlay("atk");
            }
         }
      }

      public function R1chk(param1:TouchEvent):void
      {
         if(this.hit == true)
         {
            if(this.hit_nmbR == 4)
            {
               this.hand[4].gotoAndStop("down");
               this.bom_mc.x = this.head_mc.x + this.hand[4].x;
               this.bom_mc.y = this.head_mc.y + this.hand[4].y;
               this.bom_mc.gotoAndPlay(this.combo);
               this.score += this.combos;
               this.hit_nmbR = Math.ceil(Math.random() * 2);
               if(this.hit_nmbR == 1)
               {
                  this.hit_nmbR = 5;
               }
               else
               {
                  this.hit_nmbR = 6;
               }
               this.hand[this.hit_nmbR].gotoAndPlay("up");
               if(this.hit_nmbR <= 3)
               {
                  this.head_mc.gotoAndStop("left");
               }
               else
               {
                  this.head_mc.gotoAndStop("right");
               }
               this.hit_sum++;
               this.total_time += this.add_time;
               this.comb_mc.gotoAndPlay("hit");
               this.hit = true;
            }
            else
            {
               this.hit = false;
               this.head_mc.gotoAndPlay("atk");
            }
         }
      }

      public function R2chk(param1:TouchEvent):void
      {
         if(this.hit == true)
         {
            if(this.hit_nmbR == 5)
            {
               this.hand[5].gotoAndStop("down");
               this.bom_mc.x = this.head_mc.x + this.hand[5].x;
               this.bom_mc.y = this.head_mc.y + this.hand[5].y;
               this.bom_mc.gotoAndPlay(this.combo);
               this.score += this.combos;
               this.hit_nmbR = Math.ceil(Math.random() * 2);
               if(this.hit_nmbR == 1)
               {
                  this.hit_nmbR = 4;
               }
               else
               {
                  this.hit_nmbR = 6;
               }
               this.hand[this.hit_nmbR].gotoAndPlay("up");
               if(this.hit_nmbR <= 3)
               {
                  this.head_mc.gotoAndStop("left");
               }
               else
               {
                  this.head_mc.gotoAndStop("right");
               }
               this.hit_sum++;
               this.total_time += this.add_time;
               this.comb_mc.gotoAndPlay("hit");
               this.hit = true;
            }
            else
            {
               this.hit = false;
               this.head_mc.gotoAndPlay("atk");
            }
         }
      }

      public function R3chk(param1:TouchEvent):void
      {
         if(this.hit == true)
         {
            if(this.hit_nmbR == 6)
            {
               this.hand[6].gotoAndStop("down");
               this.bom_mc.x = this.head_mc.x + this.hand[6].x;
               this.bom_mc.y = this.head_mc.y + this.hand[6].y;
               this.bom_mc.gotoAndPlay(this.combo);
               this.score += this.combos;
               this.hit_nmbR = Math.ceil(Math.random() * 2);
               if(this.hit_nmbR == 1)
               {
                  this.hit_nmbR = 4;
               }
               else
               {
                  this.hit_nmbR = 5;
               }
               this.hand[this.hit_nmbR].gotoAndPlay("up");
               if(this.hit_nmbR <= 3)
               {
                  this.head_mc.gotoAndStop("left");
               }
               else
               {
                  this.head_mc.gotoAndStop("right");
               }
               this.hit_sum++;
               this.total_time += this.add_time;
               this.comb_mc.gotoAndPlay("hit");
               this.hit = true;
            }
            else
            {
               this.hit = false;
               this.head_mc.gotoAndPlay("atk");
            }
         }
      }

      public function onwinTimer(param1:TimerEvent):void
      {
         this.hit = false;
         this.ggg++;
         this.myTimer.stop();
         this.t_mc.stop();
         this.myTimer.removeEventListener(TimerEvent.TIMER, this.myTimerFunc);
         removeEventListener(Event.ENTER_FRAME, this.actor_go);
         if(this.ggg >= 5)
         {
            this.ggg = 0;
            this.winTimer.stop();
            this.winTimer.removeEventListener(TimerEvent.TIMER, this.onwinTimer);
            gotoAndStop("over");
            this.win = false;
         }
      }

      public function go_again(param1:MouseEvent):void
      {
         if(this.over == true)
         {
            if(this.getnew == true)
            {
               this.UpdateGameDQuery("name1", this.role[1][1], "1");
               this.UpdateGameDQuery("score1", this.role[1][2], "1");
               this.UpdateGameDQuery("name2", this.role[2][1], "1");
               this.UpdateGameDQuery("score2", this.role[2][2], "1");
               this.UpdateGameDQuery("name3", this.role[3][1], "1");
               this.UpdateGameDQuery("score3", this.role[3][2], "1");
               this.UpdateGameDQuery("name4", this.role[4][1], "1");
               this.UpdateGameDQuery("score4", this.role[4][2], "1");
               this.UpdateGameDQuery("name5", this.role[5][1], "1");
               this.UpdateGameDQuery("score5", this.role[5][2], "1");
            }
            gotoAndStop("menu");
         }
      }

      public function back_menu1(param1:MouseEvent):void
      {
         gotoAndStop("menu");
      }

      internal function frame1():*
      {
         this.role = new Array(6);
         this.r = 0;
         while(this.r < 6)
         {
            this.role[this.r] = new Array(3);
            var _loc1_ = this;
            var _loc2_ = _loc1_.r + 1;
            _loc1_.r = _loc2_;
         }
         this.lastname = "CaPoo";
         this.level = 1;
         this.exp_n = 0;
         this.exp_h = 0;
         this.level_max = 6;
         this.level_exp = new Array(6);
         this.level_exp[1] = 50;
         this.level_exp[2] = 300;
         this.level_exp[3] = 350;
         this.level_exp[4] = 352;
         this.level_exp[5] = 353;
         this.level_exp[6] = 354;
         this.curr = 0;
         this.get_down = false;
         NativeApplication.nativeApplication.addEventListener(Event.ACTIVATE, this.handleActivate, false, 0, true);
         NativeApplication.nativeApplication.addEventListener(Event.DEACTIVATE, this.handleDeactivate, false, 0, true);
         NativeApplication.nativeApplication.addEventListener(KeyboardEvent.KEY_DOWN, this.handleKeys, false, 0, true);
         NativeApplication.nativeApplication.addEventListener(KeyboardEvent.KEY_UP, this.handleKeyU, false, 0, true);
      }

      internal function frame2():*
      {
         stop();
      }

      internal function frame3():*
      {
         this.curr = 1;
         this.go_menu.addEventListener(MouseEvent.CLICK, this.go_menua);
      }

      internal function frame4():*
      {
         stop();
         this.curr = 2;
         this.hit_point.text = String(this.role[1][2]);
         this.GO.addEventListener(MouseEvent.CLICK, this.go_start);
         this.rank.addEventListener(MouseEvent.CLICK, this.go_rank);
         if(this.level >= this.level_max)
         {
            this.level = this.level_max;
         }
         this.level_txt.text = "Lv " + String(this.level);
         this.exp_h = this.level_exp[this.level];
         this.exp_txt.text = String(this.exp_n) + "/" + String(this.exp_h);
         this.lines = this.exp_n * 100 / this.exp_h;
         if(this.lines >= 100)
         {
            this.lines = 101;
         }
         else
         {
            this.lines++;
         }
         this.exp_mc.line_mc.gotoAndStop(this.lines);
         if(this.role[1][2] >= 300)
         {
            this.capoo.gotoAndStop(10);
         }
         else if(this.role[1][2] >= 250)
         {
            this.capoo.gotoAndStop(9);
         }
         else if(this.role[1][2] >= 200)
         {
            this.capoo.gotoAndStop(8);
         }
         else if(this.role[1][2] >= 180)
         {
            this.capoo.gotoAndStop(7);
         }
         else if(this.role[1][2] >= 150)
         {
            this.capoo.gotoAndStop(6);
         }
         else if(this.role[1][2] >= 130)
         {
            this.capoo.gotoAndStop(5);
         }
         else if(this.role[1][2] >= 100)
         {
            this.capoo.gotoAndStop(4);
         }
         else if(this.role[1][2] >= 60)
         {
            this.capoo.gotoAndStop(3);
         }
         else if(this.role[1][2] >= 30)
         {
            this.capoo.gotoAndStop(2);
         }
         else
         {
            this.capoo.gotoAndStop(1);
         }
         this.capoo.addEventListener(MouseEvent.CLICK, this.capoo_hit);
      }

      internal function frame5():*
      {
         this.curr = 3;
      }

      internal function frame6():*
      {
         this.curr = 4;
         this.t_mc.stop();
         this.head_mc.gotoAndStop("mid");
         this.bg_mc.gotoAndStop("a");
         Multitouch.inputMode = MultitouchInputMode.TOUCH_POINT;
         this.hand = new Array(6);
         this.hand[1] = this.head_mc.L1_mc;
         this.hand[2] = this.head_mc.L2_mc;
         this.hand[3] = this.head_mc.L3_mc;
         this.hand[4] = this.head_mc.R1_mc;
         this.hand[5] = this.head_mc.R2_mc;
         this.hand[6] = this.head_mc.R3_mc;
         this.win = false;
         this.game_start = false;
         this.hit = false;
         this.hit_nmbL = 0;
         this.hit_nmbR = 0;
         this.hit_sum = 0;
         this.score = 0;
         this.combo = "hita";
         this.combos = 51;
         this.total_time = 100;
         this.all_time = this.total_time;
         this.add_time = 2;
         this.time_line.gotoAndStop(101);
         this.timer_txt.text = String(this.total_time);
         this.myTimer = new Timer(100);
         this.myTimer.addEventListener(TimerEvent.TIMER, this.myTimerFunc);
         addEventListener(Event.ENTER_FRAME, this.actor_go);
         this.L1_but.addEventListener(TouchEvent.TOUCH_BEGIN, this.L1chk);
         this.L2_but.addEventListener(TouchEvent.TOUCH_BEGIN, this.L2chk);
         this.L3_but.addEventListener(TouchEvent.TOUCH_BEGIN, this.L3chk);
         this.R1_but.addEventListener(TouchEvent.TOUCH_BEGIN, this.R1chk);
         this.R2_but.addEventListener(TouchEvent.TOUCH_BEGIN, this.R2chk);
         this.R3_but.addEventListener(TouchEvent.TOUCH_BEGIN, this.R3chk);
         this.winTimer = new Timer(200);
         this.ggg = 0;
         this.winTimer.addEventListener(TimerEvent.TIMER, this.onwinTimer);
         this.game_start = true;
      }

      internal function frame7():*
      {
         if(this.isShow == false)
         {
            this.isShow = true;
         }
         this.curr = 5;
         this.skip_b = false;
         this.over = false;
         this.sco = 0;
         this.add_sco = 0;
         this.add_exp = 0;
         this.all_exp = 0;
         this.now_exp = 0;
         this.gg_exp = 0;
         this.lv_up = false;
         this.score_txt.text = String(this.hit_sum);
         this.down_mc.stop();
         this.add_sco = this.score / 20;
         this.add_exp = this.score / 2000;
         if(this.add_exp == 0)
         {
            this.add_exp = 1;
         }
         this.all_exp = this.score / 100;
         this.gg_exp = this.exp_n + this.all_exp;
         this.exp_txt.text = String(this.exp_n) + "/" + String(this.exp_h);
         this.lines = this.exp_n * 100 / this.exp_h;
         if(this.lines >= 100)
         {
            this.lines = 101;
         }
         else
         {
            this.lines++;
         }
         this.exp_mc.line_mc.gotoAndStop(this.lines);
         stop();
         this.getnew = false;
         this.gscr = 0;
         this.gsit = 0;
         this.ss = 1;
         for(; this.ss < 6; _loc1_ = this, (_loc2_ = _loc1_.ss + 1, _loc1_.ss = _loc2_))
         {
            if(this.getnew == false)
            {
               if(this.hit_sum > this.role[this.ss][2])
               {
                  this.getnew = true;
                  this.gname = this.role[this.ss][1];
                  this.gscr = this.role[this.ss][2];
                  this.role[this.ss][2] = this.hit_sum;
                  this.gsit = this.ss;
               }
            }
            else
            {
               this.sn = this.role[this.ss][1];
               this.sc = this.role[this.ss][2];
               this.role[this.ss][1] = this.gname;
               this.role[this.ss][2] = this.gscr;
               this.gname = this.sn;
               this.gscr = this.sc;
            }
         }
         this.again.addEventListener(MouseEvent.CLICK, this.go_again);
      }

      internal function frame8():*
      {
         this.curr = 6;
         this.back_menu.addEventListener(MouseEvent.CLICK, this.back_menu1);
         trace(this.role[1][1]);
         trace(this.role[2][1]);
         trace(this.role[3][1]);
         trace(this.role[4][1]);
         trace(this.role[5][1]);
         trace(" ");
         this.name1.text = String(this.role[1][1]);
         this.scr1.text = String(this.role[1][2]);
         this.name2.text = String(this.role[2][1]);
         this.scr2.text = String(this.role[2][2]);
         this.name3.text = String(this.role[3][1]);
         this.scr3.text = String(this.role[3][2]);
         this.name4.text = String(this.role[4][1]);
         this.scr4.text = String(this.role[4][2]);
         this.name5.text = String(this.role[5][1]);
         this.scr5.text = String(this.role[5][2]);
      }
   }
}
